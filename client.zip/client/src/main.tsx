import { createRoot } from "react-dom/client";
import { AppMIS } from "./AppMIS";
import "./index.css";

createRoot(document.getElementById("root")!).render(<AppMIS />);
