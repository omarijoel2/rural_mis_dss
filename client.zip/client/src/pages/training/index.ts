export { default as CourseCatalog } from './CourseCatalog';
export { default as MyLearning } from './MyLearning';
export { default as KnowledgeBase } from './KnowledgeBase';
export { default as SopsPage } from './SopsPage';
export { default as SkillsMatrix } from './SkillsMatrix';
export { default as CertificatesPage } from './CertificatesPage';
